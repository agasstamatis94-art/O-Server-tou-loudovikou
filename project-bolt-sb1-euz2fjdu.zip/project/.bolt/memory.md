# Project memory

## Product intent & audience

- Landing page for the Discord server "Ο Server Του Loudouvikou".
- Goal: showcase server features and drive invites via a prominent "join" CTA.
- Primary audience: prospective Discord community members (Greek-speaking).
- User explicitly wants real, live server stats (member count, online count, etc.) — not placeholder/random numbers.

## Brand personality & voice

- Community-oriented, welcoming, modern.
- Content written in Greek (el).
- Real server name confirmed: "Ο Server Του Loudouvikou".

## Visual design & UX direction

- Dark Discord-inspired theme; cyan/blue neon aesthetic.
- Inter font loaded in `index.html`.
- User-provided assets: large banner as hero background, cyan emblem as logo across navbar/hero/footer and as favicon.
- Sections built: responsive navbar (scroll-aware blur + mobile burger), hero (banner bg + emblem logo + gradient title + join button + member-count badge), feature cards (6, hover animations), animated stat counters (count-up on scroll), rules section, FAQ accordion, final CTA, footer.
- Components under `src/components/`; composed in `App.jsx`.
- Icons via `lucide-react`.
- Stat counters currently show placeholder values — must be replaced with real Discord data or removed.

## Decisions, constraints & rationale

- Stack: Vite + React, Tailwind CSS, lucide-react; no extra UI/icon packages installed.
- Import alias `@/` → `src/` per global prompt instructions.
- Build verified passing after branding asset integration.
- Placeholder Discord invite `https://discord.gg/ΤΟ-INVITE-SOU` still used on all CTAs — needs real link.
- Decision: integrate Discord API to fetch live member/online counts instead of hardcoded placeholders.
- If Discord API only returns approximate counts, display clearly as "περίπου" (approximately).
- User rejected random/placeholder numbers — all stats must reflect real server data.

## Open questions & assumptions

- Need real Discord invite link from user to: (a) replace placeholder CTAs, (b) fetch live server stats via Discord API.
- Discord API integration method not yet implemented — awaiting invite link to determine endpoint/approach.
- If exact member count isn't available via public API, may need Discord bot or server widget enablement.
- Specific feature set of the actual server still unknown — current features are generic gaming/community placeholders.
- Member count "2.400+" is a placeholder pending real data — user flagged this as unacceptable.